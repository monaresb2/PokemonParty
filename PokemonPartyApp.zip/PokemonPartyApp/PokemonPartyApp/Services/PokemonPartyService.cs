﻿
using System;
using System.Collections.Generic;
using System.Linq;
using PokemonPartyApp.Models;
using System.Text.Json;

namespace PokemonPartyApp.Services
{
    public class PokemonPartyService
    {
        private static readonly List<Pokemon> AllPokemon = new List<Pokemon>
        {
            new Pokemon { Name = "Pikachu", ImageUrl = "/images/pikachu.png" },
            new Pokemon { Name = "Bulbasaur", ImageUrl = "/images/bulbasaur.png" },
            new Pokemon { Name = "Charmander", ImageUrl = "/images/charmander.png" },
            new Pokemon { Name = "Squirtle", ImageUrl = "/images/squirtle.png" },
            new Pokemon { Name = "Jigglypuff", ImageUrl = "/images/jigglypuff.png" },
            new Pokemon { Name = "Meowth", ImageUrl = "/images/meowth.png" },
            new Pokemon { Name = "Psyduck", ImageUrl = "/images/psyduck.png" }
        };

        private const int MaxPartySize = 6;

        public List<Pokemon> GenerateRandomParty()
        {
            var random = new Random();
            var party = AllPokemon
                .Where(p => p.Name != "Pikachu")
                .OrderBy(x => random.Next())
                .Take(MaxPartySize - 1)
                .ToList();

            party.Add(AllPokemon.First(p => p.Name == "Pikachu"));
            return party.OrderBy(x => random.Next()).ToList();
        }

        public void SaveParty(List<Pokemon> party)
        {
            var json = JsonSerializer.Serialize(party);
            System.IO.File.WriteAllText("savedParty.json", json);
        }

        public List<Pokemon> LoadParty()
        {
            if (!System.IO.File.Exists("savedParty.json"))
                return null;

            var json = System.IO.File.ReadAllText("savedParty.json");
            return JsonSerializer.Deserialize<List<Pokemon>>(json);
        }
    }
}
