﻿using Microsoft.AspNetCore.Mvc;
using PokemonPartyApp.Models;
using PokemonPartyApp.Services;
using System.Collections.Generic;
using System.Linq;

namespace PokemonPartyApp.Controllers
{
    public class PokemonPartyController : Controller
    {
        private readonly PokemonPartyService _partyService;

        public PokemonPartyController()
        {
            _partyService = new PokemonPartyService();
        }

        public IActionResult Index()
        {
            var party = _partyService.GenerateRandomParty();
            return View(party);
        }

        [HttpPost]
        public IActionResult Save(List<string> party)
        {
            var pokemonParty = party.Select(p => new Pokemon { Name = p, ImageUrl = GetImageUrl(p) }).ToList();
            _partyService.SaveParty(pokemonParty);
            return RedirectToAction("Index");
        }

        public IActionResult Load()
        {
            var party = _partyService.LoadParty();
            if (party == null)
                return RedirectToAction("Index");

            return View("Index", party);
        }

        private string GetImageUrl(string name)
        {
            return name switch
            {
                "Pikachu" => "/images/pikachu.png",
                "Bulbasaur" => "/images/bulbasaur.png",
                "Charmander" => "/images/charmander.png",
                "Squirtle" => "/images/squirtle.png",
                "Jigglypuff" => "/images/jigglypuff.png",
                "Meowth" => "/images/meowth.png",
                "Psyduck" => "/images/psyduck.png",
                _ => "/images/default.png"
            };
        }
    }
}
